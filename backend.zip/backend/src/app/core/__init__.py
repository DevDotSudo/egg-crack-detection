"""Core configuration."""
